# 取得股票資料
#import pandas_datareader.data as data
#stock = data.get_data_yahoo('2330.TW', start, end)


#pip install yfinance
import yfinance as yf
import datetime
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.tsa.arima.model import ARIMA
from prophet import Prophet
import warnings
warnings.filterwarnings('ignore')

#設定爬蟲時間
start = datetime.datetime(2020, 1, 1)
end = datetime.datetime(2026, 6, 11)
# 抓取台積電股價資料
stock = yf.download("2330.TW", start, end)
print(stock.tail())

# 將 Close 壓平為 Series（yfinance MultiIndex 相容處理）
close = stock['Close'].squeeze()

import matplotlib.pyplot as plt
from matplotlib import rcParams
# 設定中文字型（Windows 通常有 Microsoft JhengHei）
rcParams['font.family'] = 'Microsoft JhengHei'  # 或 'Noto Sans CJK TC'


# 避免負號顯示錯誤
rcParams['axes.unicode_minus'] = False

# 計算均線
ma5  = close.rolling(window=5).mean()
ma20 = close.rolling(window=20).mean()
ma60 = close.rolling(window=60).mean()

# 買入點：5日均線由下往上穿越20日均線（黃金交叉）
buy_signal  = (ma5 > ma20) & (ma5.shift(1) <= ma20.shift(1))
# 賣出點：5日均線由上往下穿越20日均線（死亡交叉）
sell_signal = (ma5 < ma20) & (ma5.shift(1) >= ma20.shift(1))

# ── 未來三個月趨勢預測（線性回歸） ──────────────────────────────
# 取最近 120 個交易日作為回歸基礎
lookback = 120
close_recent = close.dropna().iloc[-lookback:]
x = np.arange(len(close_recent))
slope, intercept, r_value, _, _ = stats.linregress(x, close_recent.values)

# 產生未來 65 個交易日（約 3 個月）的日期序列（跳過週末）
last_date = close.index[-1]
future_dates = pd.bdate_range(start=last_date + pd.Timedelta(days=1), periods=65)

# 預測值
future_x = np.arange(len(close_recent), len(close_recent) + len(future_dates))
future_prices = intercept + slope * future_x

# 信賴區間（±1.5 標準差）
residuals = close_recent.values - (intercept + slope * x)
std_err = np.std(residuals)
upper_band = future_prices + 1.5 * std_err
lower_band = future_prices - 1.5 * std_err

# 建議買點：預測價格帶下緣
suggested_buy_price  = lower_band[0]
# 建議賣點：預測價格帶上緣（65天後）
suggested_sell_price = upper_band[-1]

print(f"\n📈 未來三個月趨勢預測（線性回歸，R²={r_value**2:.2f}）")
print(f"   趨勢方向：{'上升 ▲' if slope > 0 else '下降 ▼'}  斜率：{slope:.2f} NTD/日")
print(f"   建議買點區間：{lower_band[0]:,.0f} ~ {future_prices[0]:,.0f} NTD")
print(f"   建議賣點區間：{future_prices[-1]:,.0f} ~ {upper_band[-1]:,.0f} NTD")

# ── ARIMA 短期目標價預測（未來 4 週 / 20 個交易日） ────────────────
arima_lookback = 250  # 用最近 250 個交易日（約 1 年）訓練
close_arima = close.dropna().iloc[-arima_lookback:]
print("\n⏳ ARIMA 模型訓練中...")
arima_result = ARIMA(close_arima, order=(5, 1, 2)).fit()

arima_steps = 20
arima_forecast = arima_result.get_forecast(steps=arima_steps)
arima_mean    = arima_forecast.predicted_mean
arima_ci      = arima_forecast.conf_int(alpha=0.05)  # 95% 信賴區間

arima_dates = pd.bdate_range(start=last_date + pd.Timedelta(days=1), periods=arima_steps)
arima_mean.index = arima_dates
arima_ci.index   = arima_dates

week1_price  = arima_mean.iloc[4]
week2_price  = arima_mean.iloc[9]
week4_price  = arima_mean.iloc[19]
week4_lower  = arima_ci.iloc[19, 0]
week4_upper  = arima_ci.iloc[19, 1]

print(f"\n📊 ARIMA(5,1,2) 短期目標價預測")
print(f"   1 週目標價（{arima_dates[4].date()}）：{week1_price:,.0f} NTD")
print(f"   2 週目標價（{arima_dates[9].date()}）：{week2_price:,.0f} NTD")
print(f"   4 週目標價（{arima_dates[19].date()}）：{week4_price:,.0f} NTD")
print(f"   4 週信賴區間（95%）：{week4_lower:,.0f} ~ {week4_upper:,.0f} NTD")

# ── Prophet 中長期預測（未來 3 個月 / 65 個交易日） ──────────────
print("\n⏳ Prophet 模型訓練中...")
df_prophet = close.reset_index()
df_prophet.columns = ['ds', 'y']
df_prophet['ds'] = pd.to_datetime(df_prophet['ds']).dt.tz_localize(None)

prophet_model = Prophet(
    changepoint_prior_scale=0.05,   # 趨勢彈性（越大越容易轉折）
    seasonality_prior_scale=10,     # 季節性強度
    yearly_seasonality=True,
    weekly_seasonality=False,       # 股市無完整週季節性
    daily_seasonality=False,
)
prophet_model.fit(df_prophet)

prophet_future   = prophet_model.make_future_dataframe(periods=65, freq='B')
prophet_forecast = prophet_model.predict(prophet_future)

# 只取未來部分
prophet_pred = prophet_forecast[prophet_forecast['ds'] > pd.Timestamp(last_date.date())]

p_week1  = prophet_pred.iloc[4]['yhat']
p_week4  = prophet_pred.iloc[19]['yhat']
p_month3 = prophet_pred.iloc[-1]['yhat']
p_m3_lo  = prophet_pred.iloc[-1]['yhat_lower']
p_m3_hi  = prophet_pred.iloc[-1]['yhat_upper']

print(f"\n🔮 Prophet 中長期目標價預測")
print(f"   1 週目標價（{prophet_pred.iloc[4]['ds'].date()}）：{p_week1:,.0f} NTD")
print(f"   4 週目標價（{prophet_pred.iloc[19]['ds'].date()}）：{p_week4:,.0f} NTD")
print(f"   3 個月目標價（{prophet_pred.iloc[-1]['ds'].date()}）：{p_month3:,.0f} NTD")
print(f"   3 個月信賴區間（80%）：{p_m3_lo:,.0f} ~ {p_m3_hi:,.0f} NTD")

#線型圖，收盤價、5日均線、20日均線、60日均線
# 建立圖表
plt.figure(figsize=(16, 8))


# 藍色曲線：收盤價
plt.plot(stock['Close'], label='收盤價', color='blue')


# 橘色曲線：5 日均線
plt.plot(ma5, label='5 日均線 (短期)', color='orange')


# 綠色曲線：20 日均線
plt.plot(ma20, label='20 日均線 (中期)', color='green')


# 紅色曲線：60 日均線
plt.plot(ma60, label='60 日均線 (長期)', color='red')


# 買入點：綠色向上三角形
plt.scatter(close.index[buy_signal], close[buy_signal],
            marker='^', color='lime', s=120, zorder=5, label='買入點 (黃金交叉)')

# 賣出點：紅色向下三角形
plt.scatter(close.index[sell_signal], close[sell_signal],
            marker='v', color='red', s=120, zorder=5, label='賣出點 (死亡交叉)')

# ── 未來三個月趨勢線與信賴區間 ───────────────────────────────────
plt.plot(future_dates, future_prices, color='purple', linewidth=2,
         linestyle='--', label=f'預測趨勢線 (R²={r_value**2:.2f})')
plt.fill_between(future_dates, lower_band, upper_band,
                 alpha=0.15, color='purple', label='預測區間 (±1.5σ)')

# 建議買點標記（預測區間下緣起點）
plt.scatter([future_dates[0]], [suggested_buy_price],
            marker='^', color='cyan', s=200, zorder=6,
            label=f'建議買點 ≈ {suggested_buy_price:,.0f}')

# 建議賣點標記（預測區間上緣終點）
plt.scatter([future_dates[-1]], [suggested_sell_price],
            marker='v', color='magenta', s=200, zorder=6,
            label=f'建議賣點 ≈ {suggested_sell_price:,.0f}')

# 在圖上加文字標註
plt.annotate(f'建議買點\n{suggested_buy_price:,.0f}',
             xy=(future_dates[0], suggested_buy_price),
             xytext=(future_dates[5], suggested_buy_price - std_err * 1.2),
             fontsize=9, color='cyan',
             arrowprops=dict(arrowstyle='->', color='cyan'))

plt.annotate(f'建議賣點\n{suggested_sell_price:,.0f}',
             xy=(future_dates[-1], suggested_sell_price),
             xytext=(future_dates[-20], suggested_sell_price + std_err * 0.8),
             fontsize=9, color='magenta',
             arrowprops=dict(arrowstyle='->', color='magenta'))


# 顯示圖例
plt.legend(loc=4, shadow=True, fontsize='x-large')


# 標題與座標軸
plt.title('2330.TW 台積電股價走勢（含未來三個月預測）')
plt.xlabel("日期")
plt.ylabel("股價 (NTD)")
plt.grid(True)


# 顯示圖表
plt.tight_layout()
plt.show()

# ── ARIMA 短期預測圖（最近 60 天 + 未來 4 週） ───────────────────
fig2, ax = plt.subplots(figsize=(14, 6))

# 最近 60 個交易日歷史收盤價
close_tail = close.iloc[-60:]
ax.plot(close_tail.index, close_tail.values, color='blue', linewidth=1.5, label='收盤價（近 60 日）')

# ARIMA 預測中線
ax.plot(arima_dates, arima_mean.values, color='darkorange', linewidth=2,
        linestyle='--', label='ARIMA 預測中線')

# 95% 信賴區間陰影
ax.fill_between(arima_dates, arima_ci.iloc[:, 0], arima_ci.iloc[:, 1],
                alpha=0.2, color='darkorange', label='95% 信賴區間')

# 目標價標記
for i, (label, idx, color) in enumerate([
    ('1週目標', 4,  'green'),
    ('2週目標', 9,  'purple'),
    ('4週目標', 19, 'red'),
]):
    price = arima_mean.iloc[idx]
    ax.scatter([arima_dates[idx]], [price], color=color, s=100, zorder=6)
    ax.annotate(f'{label}\n{price:,.0f}',
                xy=(arima_dates[idx], price),
                xytext=(arima_dates[idx], price + (week4_upper - week4_lower) * 0.15 * (i + 1)),
                fontsize=9, color=color, ha='center',
                arrowprops=dict(arrowstyle='->', color=color))

# 歷史與預測的分隔線
ax.axvline(x=last_date, color='gray', linestyle=':', linewidth=1.5, label='今日')
ax.text(last_date, close_tail.min() * 0.998, '今日', fontsize=8, color='gray')

ax.set_title(f'2330.TW 台積電 ARIMA(5,1,2) 短期目標價（4 週預測）')
ax.set_xlabel('日期')
ax.set_ylabel('股價 (NTD)')
ax.legend(loc='upper left', fontsize=10)
ax.grid(True, alpha=0.4)
plt.tight_layout()
plt.show()

# ── Prophet 預測圖（最近 120 天歷史 + 未來 3 個月） ──────────────
fig3, ax3 = plt.subplots(figsize=(14, 6))

# 歷史收盤價（最近 120 天）
close_120 = close.iloc[-120:]
ax3.plot(close_120.index, close_120.values, color='blue', linewidth=1.5, label='收盤價（近 120 日）')

# Prophet 預測中線與信賴區間
ax3.plot(prophet_pred['ds'], prophet_pred['yhat'],
         color='teal', linewidth=2, linestyle='--', label='Prophet 預測中線')
ax3.fill_between(prophet_pred['ds'],
                 prophet_pred['yhat_lower'],
                 prophet_pred['yhat_upper'],
                 alpha=0.2, color='teal', label='80% 信賴區間')

# 關鍵目標價標記
for label, row_idx, color in [
    ('1週目標', 4,  'green'),
    ('4週目標', 19, 'darkorange'),
    ('3月目標', -1, 'red'),
]:
    row   = prophet_pred.iloc[row_idx]
    price = row['yhat']
    date  = row['ds']
    ax3.scatter([date], [price], color=color, s=120, zorder=6)
    ax3.annotate(f"{label}\n{price:,.0f}",
                 xy=(date, price),
                 xytext=(date, price + (p_m3_hi - p_m3_lo) * 0.12),
                 fontsize=9, color=color, ha='center',
                 arrowprops=dict(arrowstyle='->', color=color))

# 趨勢轉折點
changepoints = prophet_model.changepoints
valid_cp = changepoints[changepoints >= close_120.index[0]]
for cp in valid_cp:
    ax3.axvline(x=cp, color='gray', linewidth=0.8, linestyle=':')

# 今日分隔線
ax3.axvline(x=pd.Timestamp(last_date.date()), color='black',
            linestyle=':', linewidth=1.5, label='今日')

ax3.set_title('2330.TW 台積電 Prophet 中長期目標價（3 個月預測）')
ax3.set_xlabel('日期')
ax3.set_ylabel('股價 (NTD)')
ax3.legend(loc='upper left', fontsize=10)
ax3.grid(True, alpha=0.4)
plt.tight_layout()
plt.show()
